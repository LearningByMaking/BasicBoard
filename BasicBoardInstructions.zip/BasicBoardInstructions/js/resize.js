// JavaScript Document
/*function onResize(event) {
	var height = $(window).height();
	document.getElementById("visualContainer").style.height = ((height-125)/2).toString()+"px"; 
	document.getElementById("textContainer").style.height = ((height-125)/2).toString()+"px";   
}*/
function onResize(event) {
	var height = $(window).height();
	document.getElementById("contentDiv").style.height = (height-130).toString()+"px"; 	
}